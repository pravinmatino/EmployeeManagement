﻿using EmployeeManagement.Models;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.MailHandler
{
    public class EmailHelper
    {

        private string _Host;
        private string _From;
        private string _Alias;

        public EmailHelper(IConfiguration iConfiguration)
        {
            
            var smtpSection = iConfiguration.GetSection("SmtpDetails");
            if (smtpSection != null)
            {
                _Host = smtpSection.GetSection("Host").Value;
                _From = smtpSection.GetSection("From").Value;
                _Alias = smtpSection.GetSection("Alias").Value;
            }
        }

        public void SendEmail(Email emailModel)
        {
                using (SmtpClient client = new SmtpClient(_Host))
                {
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress(_From, _Alias);
                    mailMessage.BodyEncoding = Encoding.UTF8;
                    mailMessage.To.Add(emailModel.To);
                    mailMessage.Body = emailModel.Message;
                    mailMessage.Subject = emailModel.Subject;
                    mailMessage.IsBodyHtml = emailModel.IsBodyHtml;
                    client.Send(mailMessage);
                }
            Log.Information("Email Send.");
        }
    }
}
