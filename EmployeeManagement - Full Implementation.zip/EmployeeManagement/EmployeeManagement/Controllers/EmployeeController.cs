﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.MailHandler;
using EmployeeManagement.Models;
using EmployeeManagement.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Serilog;

namespace EmployeeManagement.Controllers
{
    enum EmployeeDesignationStatus { 
        Head,
        Manager,
        Associate
    }


    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        IEmployeeRepositry _employeeRepositry;
        private EmailHelper _emailHelper;
        
        public EmployeeController(IEmployeeRepositry EmployeeRepositry, EmailHelper emailHelper)
        {
            _employeeRepositry = EmployeeRepositry;
            _emailHelper = emailHelper;
        
        }



        [HttpGet]
        [Route("GetEmployees")]
        //List All Employees
        public async Task<IActionResult> GetEmployees()
        {

            var employe = await _employeeRepositry.GetEmployees();
                if (employe == null)
                    return NotFound();
                else
                    return Ok(from e in employe orderby e.Firstname select e);
            
        }


        [HttpPost]
        [Route("AddEmployee")]
        //To CREATE Employee - And Send Email Notification
        public async Task<IActionResult> AddEmployee([FromBody]Employee  empObj)
        {

                if (ModelState.IsValid)
                {
                    var empId = await _employeeRepositry.AddEmployee(empObj);
                    if (empId > 0)
                    {
                        var SuccessEmail = new Email(
                         empObj.Emailid,
                         "Employee Details Added Successfully",
                         "",
                         false);

                        _emailHelper.SendEmail(SuccessEmail);

                        return Ok(empId);
                    }
                    else
                    {
                        return NotFound();
                    }

                }
            return BadRequest();
        }



        [HttpPost]
        [Route("UpdateEmployee")]
        //- Modify Employee
        public async Task<IActionResult> UpdateEmployee([FromBody] Employee empObj)
        {
            if (ModelState.IsValid)
            {
                    await _employeeRepositry.UpdateEmployee(empObj);
                    return Ok();
                
            }

            return BadRequest();
        }


        [HttpPost]
        [Route("DeleteEmployee")]
        //To DELETE Employee - And Send Email Notification
        public async Task<IActionResult> DeleteEmployee(int? empId)
        {
            int result = 0;
            String _ToEmployee = empId.ToString();

            if (empId == null)
            {
                return BadRequest();
            }

            result = await _employeeRepositry.DeleteEmployee(empId);
                if (result == 0)
                {
                    return NotFound();
                }

            var RemoveEmployeEmail = new Email(
                 _ToEmployee,
                 "Employee Details Removed.",
                 "",
                 false);

            _emailHelper.SendEmail(RemoveEmployeEmail);


            return Ok();
            
        }


        /// <summary Newly Added Method>
        ///  List Employees with Filter
        /// </summary>
        /// <param name="empObj"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetEmployeeBasedOnFilter")]
        public async Task<IActionResult> GetEmployeeBasedOnFilter([FromBody] Employee empObj)
        {

            var employe = await _employeeRepositry.GetEmployees();
            List<Employee> result = new List<Employee>();
            if (empObj == null)
                return NotFound();
            else
            {
                if (empObj.EmpId > 0)
                    result = employe.Where(emp => empObj.EmpId.Equals(emp.EmpId)).ToList();

                if (empObj.DepartmentId != null)
                    result = employe.Where(emp => empObj.DepartmentId.Equals(emp.DepartmentId)).ToList();

                if (empObj.Firstname != null)
                    result = employe.Where(emp => empObj.Firstname.Contains(emp.Firstname)).ToList();

                if (empObj.Lastname != null)
                    result = employe.Where(emp => empObj.Lastname.Contains(emp.Lastname)).ToList();

                return Ok(result);

            }
        }


        /// <summary  Newly Added Method>
        /// Get Employee Status - Newly Added
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetEmployeeStatusById")]
        public async Task<IActionResult> GetEmployeeStatusById(int? empId)
        {
            Log.Information("Checked Status For Employee Id - " + empId);

            var employe = await _employeeRepositry.GetEmployees();
            if (employe == null)
                return NotFound();
            else
            {

                    var EmployeeStatus = from e in employe
                                         where e.EmpId == empId
                                         select new
                                         {
                                             e.EmpId, EmployeeDesignation = (from e2 in employe
                                                                             join e3 in employe on e2.EmpId equals e3.ManagerId where e2.ManagerId == e.EmpId
                                                                             select new
                                                                             {
                                                                                 e2, e3
                                                                             }).SingleOrDefault() != null ? EmployeeDesignationStatus.Head.ToString() :
                                          (
                                              from e2 in employe where e2.ManagerId == e.EmpId
                                              select new
                                              {
                                                  Column1 = 1
                                              }).SingleOrDefault() == null ? EmployeeDesignationStatus.Associate.ToString() : EmployeeDesignationStatus.Manager.ToString()
                                         };

                return Ok(EmployeeStatus.ToList());
            }
            
         }


    }
}
