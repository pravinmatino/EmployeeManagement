﻿using System;
using System.Collections.Generic;

namespace EmployeeManagement.Models
{
    public partial class Department
    {
        public Department()
        {
            Employee = new HashSet<Employee>();
        }

        public int Id { get; set; }
        public string Dname { get; set; }

        public virtual ICollection<Employee> Employee { get; set; }
    }
}
