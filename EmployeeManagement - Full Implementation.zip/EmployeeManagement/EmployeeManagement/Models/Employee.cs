﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeManagement.Models
{
    public partial class Employee
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmpId { get; set; }
        [Required]
        [MaxLength(100,ErrorMessage ="")] 
        public string Firstname { get; set; }
        [Required]
        [MaxLength(100, ErrorMessage = "")]
        public string Lastname { get; set; }
        [Required]
        [MaxLength(100, ErrorMessage = "")]
        [DataType(DataType.EmailAddress),Display(Name ="Email-Address")]
        public string Emailid { get; set; }
        public int? DepartmentId { get; set; }
        public int? ManagerId { get; set; }

        public string EmployeeDesignation { get; set; }
        public virtual Department Department { get; set; }
    }
}
