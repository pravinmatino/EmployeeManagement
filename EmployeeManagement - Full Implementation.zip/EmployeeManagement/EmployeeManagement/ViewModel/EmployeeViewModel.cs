﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.ViewModel
{
    public class EmployeeViewModel
    {
        public int EmployeeID { get; set; }
        public string EmployeeStatus { get; set; }
    }
}
