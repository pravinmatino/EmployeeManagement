﻿using EmployeeManagement.Models;
using EmployeeManagement.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Repository
{
    public interface IEmployeeRepositry
    {
       
        Task<List<Employee>> GetEmployees();

        
        Task<int> AddEmployee(Employee employee);

        Task<int> DeleteEmployee(int? employeeId);

        Task UpdateEmployee(Employee employee);
    }
}
