﻿using EmployeeManagement.Models;
using EmployeeManagement.ViewModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Repository
{
    public class EmployeeRepositry : IEmployeeRepositry
    {

        TMEmpDepartmentContext db;
        
        public EmployeeRepositry(TMEmpDepartmentContext _db)
        {
            db = _db;

        }


        public async Task<List<Employee>> GetEmployees()
        {
            
         if (db != null)
            {
                Log.Information("DB Connection Successfull.");
                return await db.Employee.ToListAsync();
            }
            return null;
            

        }

        public async Task<int> AddEmployee(Employee employe)
        {
            if (db != null)
            {
                
                await db.Employee.AddAsync(employe);
                await db.SaveChangesAsync();
                return employe.EmpId;
            }

            return 0;
        }

        public async Task UpdateEmployee(Employee employe)
        {
            if (db != null)
            {

                db.Employee.Update(employe);
                await db.SaveChangesAsync();

            }
        }

        public async Task<int> DeleteEmployee(int? empId)
        {
            int result = 0;

            if (db != null)
            {
                
                var emp = await db.Employee.FirstOrDefaultAsync(x => x.EmpId== empId);

                if (emp != null)
                {
                    Log.Information("Deleted Employee - "+ empId.ToString());
                    db.Employee.Remove(emp);
                    result = await db.SaveChangesAsync();

                }
                return result;
            }

            return result;
        }

        
    }
}
